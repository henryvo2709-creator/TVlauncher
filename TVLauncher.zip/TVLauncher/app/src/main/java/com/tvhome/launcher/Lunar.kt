package com.tvhome.launcher

import android.icu.util.ChineseCalendar
import java.util.Calendar

/**
 * Âm lịch (tháng, ngày) cho ngày dương lịch.
 * Dùng ChineseCalendar có sẵn trong Android (API 24+). Có thể lệch 1 ngày ở vài ngày hiếm hoi
 * so với lịch âm Việt Nam (do múi giờ UTC+8 và UTC+7).
 */
fun lunarOf(year: Int, month0: Int, day: Int): Pair<Int, Int> {
    return try {
        val c = Calendar.getInstance()
        c.clear()
        c.set(year, month0, day, 12, 0, 0)
        val cc = ChineseCalendar(c.time)
        Pair(cc.get(ChineseCalendar.MONTH) + 1, cc.get(ChineseCalendar.DAY_OF_MONTH))
    } catch (e: Throwable) {
        Pair(0, 0)
    }
}
