package com.tvhome.launcher

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class Dlg {
    object None : Dlg()
    object Apps : Dlg()
    object AddWidget : Dlg()
    object Wallpaper : Dlg()
    class DockMenu(val pkg: String) : Dlg()
    class WidgetSettings(val id: String) : Dlg()
}

@Composable
fun TvDialog(title: String, onDismiss: () -> Unit, width: Int = 520, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val shape = RoundedCornerShape(20.sdp())
        Column(
            Modifier
                .width(width.sdp())
                .clip(shape)
                .background(Color(0xF2191A22))
                .border(1.dp, Color.White.copy(0.15f), shape)
                .padding(20.sdp()),
            verticalArrangement = Arrangement.spacedBy(10.sdp())
        ) {
            T(title, 20, Color.White, FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
fun TvTextField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.sdp()))
            .background(Color.White.copy(if (focused) 0.28f else 0.12f))
            .padding(horizontal = 12.sdp(), vertical = 10.sdp())
    ) {
        if (value.isEmpty()) T(hint, 15, Color.White.copy(0.45f))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 15.ssp()),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
                .onFocusChanged { focused = it.isFocused }
        )
    }
}

// ============================================================ TẤT CẢ ỨNG DỤNG

@Composable
fun AppPickerDialog(
    apps: List<AppEntry>,
    dockSet: Set<String>,
    onLaunch: (AppEntry) -> Unit,
    onAddDock: (AppEntry) -> Unit,
    onDismiss: () -> Unit
) {
    val fr = remember { FocusRequester() }
    AutoFocus(fr)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val shape = RoundedCornerShape(24.sdp())
        Column(
            Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.88f)
                .clip(shape)
                .background(Color(0xF2191A22))
                .border(1.dp, Color.White.copy(0.15f), shape)
                .padding(18.sdp())
        ) {
            T("Tất cả ứng dụng", 20, Color.White, FontWeight.SemiBold)
            T("OK: mở ứng dụng  ·  Giữ OK (hoặc phím Menu): thêm vào dock", 12, Color.White.copy(0.6f))
            Spacer(Modifier.height(8.sdp()))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 104.sdp()),
                contentPadding = PaddingValues(6.sdp()),
                verticalArrangement = Arrangement.spacedBy(8.sdp()),
                horizontalArrangement = Arrangement.spacedBy(8.sdp())
            ) {
                itemsIndexed(apps, key = { _, a -> a.pkg }) { i, a ->
                    AppCell(
                        app = a,
                        inDock = a.pkg in dockSet,
                        modifier = if (i == 0) Modifier.focusRequester(fr) else Modifier,
                        onClick = { onLaunch(a) },
                        onLong = { onAddDock(a) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppCell(app: AppEntry, inDock: Boolean, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(14.sdp()))
            .background(if (focused) Color.White.copy(0.28f) else Color.White.copy(0.06f))
            .tvClickable(onLong, onClick)
            .padding(8.sdp()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, app.label, Modifier.size(52.sdp()))
        Spacer(Modifier.height(4.sdp()))
        T(app.label, 12, if (inDock) Color(0xFF7CE0A3) else Color.White, align = TextAlign.Center)
    }
}

// ============================================================ MENU DOCK

@Composable
fun DockMenuDialog(
    app: AppEntry?,
    pkg: String,
    onMove: (Int) -> Unit,
    onRemove: () -> Unit,
    onInfo: () -> Unit,
    onDismiss: () -> Unit
) {
    val fr = remember { FocusRequester() }
    AutoFocus(fr)
    TvDialog(app?.label ?: pkg, onDismiss, width = 420) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.sdp())) {
            PillButton("< Dịch trái", focusRequester = fr) { onMove(-1) }
            PillButton("Dịch phải >") { onMove(1) }
        }
        PillButton("Gỡ khỏi dock", onClick = onRemove)
        PillButton("Thông tin ứng dụng", onClick = onInfo)
        PillButton("Đóng", onClick = onDismiss)
    }
}

// ============================================================ THÊM WIDGET

@Composable
fun AddWidgetDialog(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val fr = remember { FocusRequester() }
    AutoFocus(fr)
    TvDialog("Thêm widget", onDismiss, width = 420) {
        WIDGET_LABELS.entries.forEachIndexed { i, e ->
            PillButton(
                e.value,
                modifier = Modifier.fillMaxWidth(),
                focusRequester = if (i == 0) fr else null
            ) { onPick(e.key) }
        }
    }
}

// ============================================================ CÀI ĐẶT WIDGET

@Composable
fun WidgetSettingsDialog(cfg: WidgetCfg, onProps: (Map<String, String>) -> Unit, onDismiss: () -> Unit) {
    val fr = remember { FocusRequester() }
    AutoFocus(fr)
    val title = "Cài đặt: " + (WIDGET_LABELS[cfg.type] ?: cfg.type)
    TvDialog(title, onDismiss, width = 520) {
        when (cfg.type) {
            WType.CLOCK -> {
                val lunar = cfg.props["lunar"] != "0"
                val h12 = cfg.props["h12"] == "1"
                PillButton("Ngày âm lịch: " + if (lunar) "Bật" else "Tắt", focusRequester = fr) {
                    onProps(mapOf("lunar" to if (lunar) "0" else "1"))
                }
                PillButton("Định dạng giờ: " + if (h12) "12 giờ" else "24 giờ") {
                    onProps(mapOf("h12" to if (h12) "0" else "1"))
                }
            }
            WType.CALENDAR -> {
                val lunar = cfg.props["lunar"] != "0"
                PillButton("Hiện âm lịch: " + if (lunar) "Bật" else "Tắt", focusRequester = fr) {
                    onProps(mapOf("lunar" to if (lunar) "0" else "1"))
                }
            }
            WType.GREETING -> {
                var t by remember { mutableStateOf(cfg.props["title"] ?: "Xin chào") }
                var q by remember { mutableStateOf(cfg.props["quote"] ?: "Stay hungry, stay foolish") }
                TvTextField(t, { t = it }, "Tiêu đề (chữ cầu vồng)", focusRequester = fr)
                TvTextField(q, { q = it }, "Câu nói")
                PillButton("Lưu") {
                    onProps(mapOf("title" to t, "quote" to q))
                    onDismiss()
                }
            }
            WType.STOCKS -> {
                var s by remember { mutableStateOf(cfg.props["symbols"] ?: DEFAULT_SYMBOLS) }
                T("Mã Yahoo Finance, cách nhau bằng dấu phẩy (vd: AAPL,^GSPC,BTC-USD,GC=F,USDVND=X,VNM.VN)", 12, Color.White.copy(0.65f), maxLines = 3)
                TvTextField(s, { s = it }, "AAPL,NVDA,BTC-USD", focusRequester = fr)
                PillButton("Lưu") {
                    onProps(mapOf("symbols" to s.replace(" ", "")))
                    onDismiss()
                }
            }
            WType.WEATHER -> WeatherSettings(cfg, fr, onProps, onDismiss)
            else -> {
                T("Widget này không có tuỳ chọn riêng.", 14, Color.White.copy(0.75f))
                PillButton("Đóng", focusRequester = fr, onClick = onDismiss)
            }
        }
    }
}

@Composable
private fun WeatherSettings(cfg: WidgetCfg, fr: FocusRequester, onProps: (Map<String, String>) -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<GeoPlace>>(emptyList()) }
    var status by remember { mutableStateOf("") }
    T("Đang dùng: " + (cfg.props["name"] ?: "TP. Hồ Chí Minh"), 13, Color.White.copy(0.75f))
    TvTextField(q, { q = it }, "Nhập tên thành phố (vd: Hà Nội, Da Nang, Tokyo)", focusRequester = fr)
    PillButton("Tìm") {
        if (q.isNotBlank()) {
            status = "Đang tìm…"
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    try {
                        geocode(q.trim())
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                results = r
                status = if (r.isEmpty()) "Không tìm thấy" else ""
            }
        }
    }
    if (status.isNotEmpty()) T(status, 13, Color.White.copy(0.7f))
    results.forEach { p ->
        PillButton(p.name + if (p.country.isNotEmpty()) " — " + p.country else "", Modifier.fillMaxWidth()) {
            onProps(mapOf("name" to p.name, "lat" to p.lat.toString(), "lon" to p.lon.toString()))
            onDismiss()
        }
    }
}

// ============================================================ HÌNH NỀN

@Composable
fun WallpaperDialog(store: LauncherStore, onDismiss: () -> Unit) {
    val ctx: Context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fr = remember { FocusRequester() }
    AutoFocus(fr)
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    TvDialog("Hình nền", onDismiss, width = 540) {
        WALLPAPERS.forEachIndexed { i, w ->
            PillButton(
                w.name,
                modifier = Modifier.fillMaxWidth(),
                focusRequester = if (i == 0) fr else null,
                active = store.wallpaper == i
            ) { store.setWallpaper(i) }
        }
        T("Hoặc dùng ảnh riêng — dán đường dẫn ảnh (jpg/png):", 12, Color.White.copy(0.65f))
        TvTextField(url, { url = it }, "https://…/anh.jpg")
        PillButton("Tải ảnh làm hình nền", active = store.wallpaper == -1) {
            if (url.isNotBlank()) {
                status = "Đang tải…"
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        try {
                            val f = File(ctx.filesDir, "wallpaper.jpg")
                            Net.download(url.trim(), f)
                            val bmp = loadWallpaperBitmap(ctx)
                            if (bmp == null) {
                                f.delete()
                                false
                            } else {
                                true
                            }
                        } catch (e: Exception) {
                            false
                        }
                    }
                    if (ok) {
                        store.setWallpaper(-1)
                        status = "Đã đặt hình nền"
                    } else {
                        status = "Tải ảnh thất bại"
                    }
                }
            }
        }
        if (status.isNotEmpty()) T(status, 13, Color.White.copy(0.8f))
        PillButton("Đóng", onClick = onDismiss)
    }
}
