package com.tvhome.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    /** Tăng mỗi lần quay lại launcher (nhấn Home, thoát app…) để nạp lại danh sách app và thoát chế độ chỉnh sửa. */
    var resumeCount by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp(this) }
    }

    override fun onResume() {
        super.onResume()
        resumeCount++
    }
}

@Composable
fun LauncherApp(act: MainActivity) {
    val store = remember { LauncherStore(act) }
    var apps by remember { mutableStateOf(emptyList<AppEntry>()) }
    var dialog by remember { mutableStateOf<Dlg>(Dlg.None) }
    var editing by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var grabbedId by remember { mutableStateOf<String?>(null) }
    var focusedApp by remember { mutableStateOf<AppEntry?>(null) }
    val dockFocus = remember { FocusRequester() }
    val toolbarFocus = remember { FocusRequester() }

    LaunchedEffect(act.resumeCount) {
        editing = false
        grabbedId = null
        dialog = Dlg.None
        apps = withContext(Dispatchers.IO) { loadApps(act) }
        store.ensureDock(apps)
    }

    val appMap = remember(apps) { apps.associateBy { it.pkg } }
    val dockApps = store.dock.mapNotNull { appMap[it] }

    // Đưa focus về dock khi mở app xong / thoát chế độ chỉnh sửa
    LaunchedEffect(editing, apps.isNotEmpty()) {
        if (!editing) {
            delay(250)
            try {
                dockFocus.requestFocus()
            } catch (e: Exception) {
            }
        } else {
            delay(250)
            try {
                toolbarFocus.requestFocus()
            } catch (e: Exception) {
            }
        }
    }

    BackHandler(enabled = editing && dialog == Dlg.None) {
        if (grabbedId != null) grabbedId = null else editing = false
    }

    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    fun forceQuit(pkg: String) {
        try {
            (act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
        } catch (e: Exception) {
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val scale = maxWidth.value / 960f
        CompositionLocalProvider(LocalScale provides scale) {
            Wallpaper(store)

            Column(Modifier.fillMaxSize().padding(horizontal = 28.sdp(), vertical = 18.sdp())) {
                Box(Modifier.fillMaxWidth().height(44.sdp()), contentAlignment = Alignment.CenterStart) {
                    if (editing) {
                        EditToolbar(
                            first = toolbarFocus,
                            onAdd = { dialog = Dlg.AddWidget },
                            onW = { d -> selectedId?.let { store.resize(it, d, 0) } },
                            onH = { d -> selectedId?.let { store.resize(it, 0, d) } },
                            onSettings = { selectedId?.let { dialog = Dlg.WidgetSettings(it) } },
                            onDelete = {
                                selectedId?.let {
                                    store.removeWidget(it)
                                    selectedId = null
                                    grabbedId = null
                                }
                            },
                            onWallpaper = { dialog = Dlg.Wallpaper },
                            onDone = {
                                grabbedId = null
                                editing = false
                            }
                        )
                    } else {
                        TopBar(
                            label = focusedApp?.label ?: "",
                            onForceQuit = {
                                focusedApp?.let {
                                    forceQuit(it.pkg)
                                    toast("Đã đóng " + it.label)
                                }
                            },
                            onRestart = {
                                focusedApp?.let {
                                    forceQuit(it.pkg)
                                    Handler(Looper.getMainLooper()).postDelayed({ launchApp(act, it.pkg) }, 450)
                                }
                            }
                        )
                    }
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    WidgetsHost(
                        store = store,
                        editing = editing,
                        selectedId = selectedId,
                        grabbedId = grabbedId,
                        onSelect = { selectedId = it },
                        onGrab = { grabbedId = it }
                    )
                }

                Box(Modifier.fillMaxWidth().height(92.sdp()), contentAlignment = Alignment.Center) {
                    if (editing) {
                        T(
                            "Mũi tên: chọn widget  ·  OK: cầm / thả để di chuyển  ·  Back: thoát",
                            13, Color.White.copy(0.85f)
                        )
                    } else {
                        Dock(
                            items = dockApps,
                            firstFocus = dockFocus,
                            onFocusApp = { focusedApp = it },
                            onLaunch = { if (!launchApp(act, it.pkg)) toast("Không mở được " + it.label) },
                            onMenu = { dialog = Dlg.DockMenu(it.pkg) },
                            onAllApps = { dialog = Dlg.Apps },
                            onEdit = {
                                editing = true
                                selectedId = store.widgets.firstOrNull()?.id
                            },
                            onSettings = {
                                try {
                                    act.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (e: Exception) {
                                    toast("Không mở được Cài đặt")
                                }
                            }
                        )
                    }
                }
            }

            when (val d = dialog) {
                Dlg.None -> {}
                Dlg.Apps -> AppPickerDialog(
                    apps = apps,
                    dockSet = store.dock.toSet(),
                    onLaunch = {
                        dialog = Dlg.None
                        if (!launchApp(act, it.pkg)) toast("Không mở được " + it.label)
                    },
                    onAddDock = {
                        toast(if (store.addDock(it.pkg)) "Đã thêm " + it.label + " vào dock" else it.label + " đã có trong dock")
                    },
                    onDismiss = { dialog = Dlg.None }
                )
                Dlg.AddWidget -> AddWidgetDialog(
                    onPick = {
                        selectedId = store.addWidget(it)
                        dialog = Dlg.None
                    },
                    onDismiss = { dialog = Dlg.None }
                )
                Dlg.Wallpaper -> WallpaperDialog(store) { dialog = Dlg.None }
                is Dlg.DockMenu -> DockMenuDialog(
                    app = appMap[d.pkg],
                    pkg = d.pkg,
                    onMove = { store.moveDock(d.pkg, it) },
                    onRemove = {
                        store.removeDock(d.pkg)
                        dialog = Dlg.None
                    },
                    onInfo = {
                        try {
                            act.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + d.pkg))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {
                            toast("Không mở được thông tin ứng dụng")
                        }
                        dialog = Dlg.None
                    },
                    onDismiss = { dialog = Dlg.None }
                )
                is Dlg.WidgetSettings -> {
                    val cfg = store.widgets.firstOrNull { it.id == d.id }
                    if (cfg == null) {
                        dialog = Dlg.None
                    } else {
                        WidgetSettingsDialog(
                            cfg = cfg,
                            onProps = { store.setProps(d.id, it) },
                            onDismiss = { dialog = Dlg.None }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Wallpaper(store: LauncherStore) {
    val ctx = LocalContext.current
    var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(store.wallpaper, store.wallpaperVersion) {
        bmp = if (store.wallpaper == -1) withContext(Dispatchers.IO) { loadWallpaperBitmap(ctx) } else null
    }
    val b = bmp
    if (store.wallpaper == -1 && b != null) {
        Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        val preset = WALLPAPERS[store.wallpaper.coerceIn(0, WALLPAPERS.size - 1)]
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(preset.colors)))
    }
    // lớp tối nhẹ giúp chữ dễ đọc
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x33000000), Color.Transparent, Color(0x66000000)))
        )
    )
}
