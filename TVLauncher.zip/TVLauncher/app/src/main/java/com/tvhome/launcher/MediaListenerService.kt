package com.tvhome.launcher

import android.service.notification.NotificationListenerService

/**
 * Service rỗng. Khi người dùng cấp quyền "Truy cập thông báo" cho app,
 * MediaSessionManager cho phép widget nhạc đọc phiên phát nhạc đang hoạt động.
 */
class MediaListenerService : NotificationListenerService()
