package com.tvhome.launcher

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

const val COLS = 12
const val ROWS = 6

object WType {
    const val CLOCK = "clock"
    const val GREETING = "greeting"
    const val MUSIC = "music"
    const val WEATHER = "weather"
    const val CALENDAR = "calendar"
    const val STOCKS = "stocks"
}

val WIDGET_LABELS = linkedMapOf(
    WType.CLOCK to "Đồng hồ",
    WType.GREETING to "Lời chào",
    WType.MUSIC to "Trình phát nhạc",
    WType.WEATHER to "Thời tiết",
    WType.CALENDAR to "Lịch tháng",
    WType.STOCKS to "Chứng khoán"
)

val WIDGET_SIZES = mapOf(
    WType.CLOCK to Pair(4, 3),
    WType.GREETING to Pair(4, 2),
    WType.MUSIC to Pair(4, 2),
    WType.WEATHER to Pair(4, 4),
    WType.CALENDAR to Pair(4, 4),
    WType.STOCKS to Pair(4, 3)
)

const val DEFAULT_SYMBOLS = "^GSPC,AAPL,NVDA,BTC-USD,GC=F,USDVND=X"

data class WidgetCfg(
    val id: String,
    val type: String,
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int,
    val props: Map<String, String> = emptyMap()
)

class WallpaperPreset(val name: String, val colors: List<Color>)

val WALLPAPERS = listOf(
    WallpaperPreset(
        "Hoàng hôn",
        listOf(Color(0xFF5B6EAE), Color(0xFFB98AB0), Color(0xFFF2A65A), Color(0xFF6B4B45), Color(0xFF2A1F22))
    ),
    WallpaperPreset("Đại dương", listOf(Color(0xFF0B3C5D), Color(0xFF328CC1), Color(0xFF0B1F33))),
    WallpaperPreset("Đêm tím", listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E))),
    WallpaperPreset("Rừng xanh", listOf(Color(0xFF0F2027), Color(0xFF2C5364), Color(0xFF1D976C))),
    WallpaperPreset("Than chì", listOf(Color(0xFF111111), Color(0xFF2B2B2B), Color(0xFF0A0A0A)))
)

data class AppEntry(val pkg: String, val label: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val map = LinkedHashMap<String, AppEntry>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
        val list = try {
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || map.containsKey(pkg)) continue
            try {
                val label = ri.loadLabel(pm).toString()
                val bmp = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
                map[pkg] = AppEntry(pkg, label, bmp)
            } catch (e: Exception) {
            }
        }
    }
    return map.values.sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String): Boolean {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return false
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }
}

fun loadWallpaperBitmap(ctx: Context): ImageBitmap? {
    val f = File(ctx.filesDir, "wallpaper.jpg")
    if (!f.exists()) return null
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    if (o.outWidth <= 0) return null
    var s = 1
    while (o.outWidth / (s * 2) >= 1920) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    return BitmapFactory.decodeFile(f.path, o2)?.asImageBitmap()
}

class LauncherStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    val widgets = mutableStateListOf<WidgetCfg>()
    val dock = mutableStateListOf<String>()
    var wallpaper by mutableIntStateOf(0)       // chỉ số preset, -1 = ảnh tự chọn
    var wallpaperVersion by mutableIntStateOf(0)
    private var dockInitialized = false

    init {
        wallpaper = prefs.getInt("wallpaper", 0)
        val ws = prefs.getString("widgets", null)
        val list = if (ws == null) defaultWidgets() else try {
            parseWidgets(ws)
        } catch (e: Exception) {
            defaultWidgets()
        }
        widgets.addAll(list)
        val ds = prefs.getString("dock", null)
        if (ds != null) {
            try {
                val a = JSONArray(ds)
                for (i in 0 until a.length()) dock.add(a.getString(i))
                dockInitialized = true
            } catch (e: Exception) {
            }
        }
    }

    private fun defaultWidgets() = listOf(
        WidgetCfg("w1", WType.GREETING, 0, 0, 4, 2),
        WidgetCfg("w2", WType.MUSIC, 0, 2, 4, 2),
        WidgetCfg("w3", WType.CLOCK, 4, 1, 4, 3),
        WidgetCfg("w4", WType.WEATHER, 8, 0, 4, 4)
    )

    private fun parseWidgets(s: String): List<WidgetCfg> {
        val a = JSONArray(s)
        val out = ArrayList<WidgetCfg>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val props = HashMap<String, String>()
            val po = o.optJSONObject("props")
            if (po != null) {
                val it = po.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    props[k] = po.getString(k)
                }
            }
            out.add(
                WidgetCfg(
                    o.getString("id"), o.getString("type"),
                    o.getInt("x"), o.getInt("y"), o.getInt("w"), o.getInt("h"), props
                )
            )
        }
        return out
    }

    fun save() {
        val wa = JSONArray()
        widgets.forEach { w ->
            wa.put(
                JSONObject()
                    .put("id", w.id).put("type", w.type)
                    .put("x", w.x).put("y", w.y).put("w", w.w).put("h", w.h)
                    .put("props", JSONObject(w.props))
            )
        }
        val da = JSONArray()
        dock.forEach { da.put(it) }
        prefs.edit()
            .putString("widgets", wa.toString())
            .putString("dock", da.toString())
            .putInt("wallpaper", wallpaper)
            .apply()
    }

    /** Lần chạy đầu: gợi ý dock từ các app quen thuộc đang cài trên TV. */
    fun ensureDock(apps: List<AppEntry>) {
        if (dockInitialized) return
        dockInitialized = true
        val installed = apps.map { it.pkg }.toSet()
        val preferred = listOf(
            "com.google.android.youtube.tv", "com.google.android.youtube",
            "com.netflix.ninja", "com.netflix.mediaclient",
            "com.spotify.tv.android", "com.spotify.music",
            "com.google.android.apps.youtube.music",
            "com.android.chrome", "com.android.vending"
        )
        val picked = preferred.filter { it in installed }.toMutableList()
        for (a in apps) {
            if (picked.size >= 6) break
            if (a.pkg !in picked) picked.add(a.pkg)
        }
        dock.clear()
        dock.addAll(picked)
        save()
    }

    // ---- dock ----
    fun addDock(pkg: String): Boolean {
        if (pkg in dock) return false
        dock.add(pkg)
        save()
        return true
    }

    fun removeDock(pkg: String) {
        dock.remove(pkg)
        save()
    }

    fun moveDock(pkg: String, delta: Int) {
        val i = dock.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= dock.size) return
        val t = dock[i]
        dock[i] = dock[j]
        dock[j] = t
        save()
    }

    // ---- widgets ----
    fun update(id: String, f: (WidgetCfg) -> WidgetCfg) {
        val i = widgets.indexOfFirst { it.id == id }
        if (i >= 0) {
            widgets[i] = f(widgets[i])
            save()
        }
    }

    fun move(id: String, dx: Int, dy: Int) = update(id) {
        it.copy(
            x = (it.x + dx).coerceIn(0, COLS - it.w),
            y = (it.y + dy).coerceIn(0, ROWS - it.h)
        )
    }

    fun resize(id: String, dw: Int, dh: Int) = update(id) {
        val nw = (it.w + dw).coerceIn(1, COLS)
        val nh = (it.h + dh).coerceIn(1, ROWS)
        it.copy(w = nw, h = nh, x = it.x.coerceAtMost(COLS - nw), y = it.y.coerceAtMost(ROWS - nh))
    }

    fun setProps(id: String, p: Map<String, String>) = update(id) { it.copy(props = it.props + p) }

    fun removeWidget(id: String) {
        widgets.removeAll { it.id == id }
        save()
    }

    fun addWidget(type: String): String {
        val (w, h) = WIDGET_SIZES[type] ?: Pair(4, 3)
        var px = 0
        var py = 0
        var found = false
        loop@ for (y in 0..ROWS - h) for (x in 0..COLS - w) {
            val free = widgets.none { it.x < x + w && x < it.x + it.w && it.y < y + h && y < it.y + it.h }
            if (free) {
                px = x; py = y; found = true
                break@loop
            }
        }
        if (!found) {
            px = 0; py = 0
        }
        val id = "w" + System.currentTimeMillis()
        widgets.add(WidgetCfg(id, type, px, py, w, h))
        save()
        return id
    }

    fun setWallpaper(i: Int) {
        wallpaper = i
        wallpaperVersion++
        save()
    }
}
