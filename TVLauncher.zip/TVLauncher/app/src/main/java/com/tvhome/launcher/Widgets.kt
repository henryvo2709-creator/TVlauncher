package com.tvhome.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun WidgetContent(cfg: WidgetCfg, editing: Boolean) {
    when (cfg.type) {
        WType.CLOCK -> ClockWidget(cfg)
        WType.GREETING -> GreetingWidget(cfg)
        WType.MUSIC -> MusicWidget(editing)
        WType.WEATHER -> WeatherWidget(cfg)
        WType.CALENDAR -> CalendarWidget(cfg)
        WType.STOCKS -> StocksWidget(cfg)
    }
}

// ============================================================ ĐỒNG HỒ

@Composable
fun ClockWidget(cfg: WidgetCfg) {
    val now by rememberNow()
    val showLunar = cfg.props["lunar"] != "0"
    val h12 = cfg.props["h12"] == "1"
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val fsDp = minOf(maxHeight.value * 0.62f, maxWidth.value / 2.9f)
        val timeFs = with(density) { fsDp.dp.toSp() }
        val dateFs = with(density) { (fsDp * 0.17f).coerceIn(10f, 30f).dp.toSp() }
        val timeStr = SimpleDateFormat(if (h12) "hh:mm" else "HH:mm", Locale.US).format(now.time)
        var dateStr = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now.time)
        if (showLunar) {
            val (lm, ld) = lunarOf(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
            if (lm > 0) dateStr += "  ·  %02d/%02d ÂL".format(lm, ld)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                dateStr, color = Color.White.copy(alpha = 0.92f), fontSize = dateFs,
                fontWeight = FontWeight.Medium, maxLines = 1
            )
            Text(
                timeStr,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = timeFs,
                fontWeight = FontWeight.Thin,
                maxLines = 1,
                softWrap = false,
                style = TextStyle(shadow = Shadow(Color(0x66000000), Offset(0f, 6f), 14f))
            )
        }
    }
}

// ============================================================ LỜI CHÀO

@Composable
fun GreetingWidget(cfg: WidgetCfg) {
    val title = cfg.props["title"] ?: "Xin chào"
    val quote = cfg.props["quote"] ?: "Stay hungry, stay foolish"
    val density = LocalDensity.current
    val rainbow = Brush.linearGradient(
        listOf(Color(0xFFFF5F6D), Color(0xFFFFC371), Color(0xFF5BE584), Color(0xFF4FC3F7), Color(0xFFB36BFF))
    )
    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 6.sdp()), contentAlignment = Alignment.CenterStart) {
        val tfs = with(density) { minOf(maxHeight.value * 0.5f, 64f * LocalScale.current).dp.toSp() }
        Column {
            BasicText(
                title,
                style = TextStyle(
                    brush = rainbow, fontSize = tfs,
                    fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold
                ),
                maxLines = 1
            )
            T(quote, 19, Color.White, FontWeight.Medium, maxLines = 2)
        }
    }
}

// ============================================================ NHẠC

private class MediaState(
    val title: String,
    val artist: String,
    val art: ImageBitmap?,
    val playing: Boolean,
    val pos: Long,
    val dur: Long
)

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun MusicWidget(editing: Boolean) {
    val ctx = LocalContext.current
    var perm by remember { mutableStateOf(true) }
    var ctrl by remember { mutableStateOf<MediaController?>(null) }
    var ms by remember { mutableStateOf<MediaState?>(null) }

    LaunchedEffect(Unit) {
        var lastKey = ""
        var lastArt: ImageBitmap? = null
        while (true) {
            perm = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            if (perm) {
                try {
                    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                    val list = msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
                    val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                        ?: list.firstOrNull()
                    ctrl = c
                    val md = c?.metadata
                    if (c == null || md == null) {
                        ms = null
                    } else {
                        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
                            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
                        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
                        val key = c.packageName + "|" + title + "|" + artist
                        if (key != lastKey || lastArt == null) {
                            lastKey = key
                            val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                            lastArt = bmp?.asImageBitmap()
                        }
                        val ps = c.playbackState
                        val playing = ps?.state == PlaybackState.STATE_PLAYING
                        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION).coerceAtLeast(0L)
                        var pos = 0L
                        if (ps != null) {
                            pos = ps.position
                            if (playing) {
                                pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
                            }
                        }
                        if (pos < 0) pos = 0
                        if (dur > 0 && pos > dur) pos = dur
                        ms = MediaState(title, artist, lastArt, playing, pos, dur)
                    }
                } catch (e: Exception) {
                    ms = null
                }
            }
            delay(1000)
        }
    }

    Box(Modifier.fillMaxSize().glass(16.sdp()).padding(10.sdp())) {
        val m = ms
        when {
            !perm -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                T("Cần quyền để hiện bài đang phát", 13, Color.White.copy(0.85f), maxLines = 2, align = TextAlign.Center)
                Spacer(Modifier.height(6.sdp()))
                if (!editing) {
                    PillButton("Cấp quyền") {
                        try {
                            ctx.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {
                        }
                    }
                }
            }
            m == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                T("Không có nhạc đang phát", 14, Color.White.copy(0.7f))
            }
            else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.sdp()).clip(RoundedCornerShape(8.sdp()))
                            .background(Color.White.copy(0.15f))
                    ) {
                        if (m.art != null) {
                            Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                    }
                    Spacer(Modifier.width(10.sdp()))
                    Column(Modifier.weight(1f)) {
                        T(m.title, 15, Color.White, FontWeight.SemiBold)
                        T(m.artist, 13, Color.White.copy(0.7f))
                    }
                    val c = ctrl
                    TransportBtn(0, editing) { c?.transportControls?.skipToPrevious() }
                    TransportBtn(if (m.playing) 3 else 1, editing) {
                        if (m.playing) c?.transportControls?.pause() else c?.transportControls?.play()
                    }
                    TransportBtn(2, editing) { c?.transportControls?.skipToNext() }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(fmtTime(m.pos), 11, Color.White.copy(0.8f))
                    Box(
                        Modifier.weight(1f).padding(horizontal = 8.sdp()).height(3.sdp())
                            .clip(CircleShape).background(Color.White.copy(0.3f))
                    ) {
                        val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
                        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Color.White))
                    }
                    T(if (m.dur > 0) "-" + fmtTime(m.dur - m.pos) else "--:--", 11, Color.White.copy(0.8f))
                }
            }
        }
    }
}

/** kind: 0 prev, 1 play, 2 next, 3 pause */
@Composable
private fun TransportBtn(kind: Int, editing: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val base = Modifier
        .size(28.sdp())
        .clip(CircleShape)
        .background(if (focused) Color.White.copy(0.9f) else Color.Transparent)
    val m = if (editing) {
        base
    } else {
        base.onFocusChanged { f -> focused = f.isFocused }.tvClickable(null, onClick)
    }
    Canvas(m.padding(7.sdp())) {
        val col = if (focused) Color.Black else Color.White
        val w = this.size.width
        val h = this.size.height
        when (kind) {
            1 -> drawPath(Path().apply { moveTo(w * 0.15f, 0f); lineTo(w, h / 2); lineTo(w * 0.15f, h); close() }, col)
            3 -> {
                drawRect(col, Offset(w * 0.1f, 0f), Size(w * 0.28f, h))
                drawRect(col, Offset(w * 0.62f, 0f), Size(w * 0.28f, h))
            }
            2 -> {
                drawPath(Path().apply { moveTo(0f, 0f); lineTo(w * 0.75f, h / 2); lineTo(0f, h); close() }, col)
                drawRect(col, Offset(w * 0.82f, 0f), Size(w * 0.18f, h))
            }
            else -> {
                drawPath(Path().apply { moveTo(w, 0f); lineTo(w * 0.25f, h / 2); lineTo(w, h); close() }, col)
                drawRect(col, Offset(0f, 0f), Size(w * 0.18f, h))
            }
        }
    }
}

// ============================================================ THỜI TIẾT

private val SUN = Color(0xFFFFC83D)
private val CLOUD = Color(0xFFEFF3F8)
private val RAIN = Color(0xFF6EC1FF)

private fun DrawScope.drawSun(c: Offset, r: Float) {
    drawCircle(SUN, r, c)
    for (i in 0 until 8) {
        val a = Math.toRadians(i * 45.0)
        val dx = Math.cos(a).toFloat()
        val dy = Math.sin(a).toFloat()
        drawLine(
            SUN,
            Offset(c.x + dx * r * 1.4f, c.y + dy * r * 1.4f),
            Offset(c.x + dx * r * 1.8f, c.y + dy * r * 1.8f),
            strokeWidth = r * 0.22f, cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawCloud(cx: Float, cy: Float, w: Float, color: Color) {
    val u = w / 4f
    drawRoundRect(color, Offset(cx - w / 2, cy), Size(w, u * 1.1f), CornerRadius(u * 0.55f))
    drawCircle(color, u * 0.8f, Offset(cx - u * 0.8f, cy + u * 0.1f))
    drawCircle(color, u * 1.1f, Offset(cx + u * 0.1f, cy - u * 0.2f))
    drawCircle(color, u * 0.75f, Offset(cx + u * 1.0f, cy + u * 0.2f))
}

@Composable
fun WeatherIcon(code: Int, iconSize: Dp) {
    val kind = wxKind(code)
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        when (kind) {
            0 -> drawSun(Offset(s / 2, s / 2), s * 0.24f)
            1 -> {
                drawSun(Offset(s * 0.36f, s * 0.36f), s * 0.17f)
                drawCloud(s * 0.56f, s * 0.5f, s * 0.8f, CLOUD)
            }
            2 -> drawCloud(s * 0.5f, s * 0.38f, s * 0.9f, CLOUD)
            3 -> {
                drawCloud(s * 0.5f, s * 0.2f, s * 0.9f, Color(0xFFCFD8E3))
                for (i in 0 until 3) {
                    val x = s * (0.32f + i * 0.18f)
                    drawLine(RAIN, Offset(x, s * 0.66f), Offset(x - s * 0.06f, s * 0.86f), strokeWidth = s * 0.06f, cap = StrokeCap.Round)
                }
            }
            4 -> {
                drawCloud(s * 0.5f, s * 0.15f, s * 0.9f, Color(0xFFB5BFCC))
                val p = Path().apply {
                    moveTo(s * 0.54f, s * 0.5f); lineTo(s * 0.4f, s * 0.74f); lineTo(s * 0.5f, s * 0.74f)
                    lineTo(s * 0.44f, s * 0.95f); lineTo(s * 0.66f, s * 0.66f); lineTo(s * 0.54f, s * 0.66f); close()
                }
                drawPath(p, SUN)
            }
            5 -> {
                drawCloud(s * 0.5f, s * 0.2f, s * 0.9f, Color(0xFFCFD8E3))
                for (i in 0 until 3) drawCircle(Color.White, s * 0.04f, Offset(s * (0.32f + i * 0.18f), s * (0.75f + (i % 2) * 0.1f)))
            }
            else -> {
                for (i in 0 until 4) {
                    drawLine(
                        Color(0xFFCFD8E3), Offset(s * 0.15f, s * (0.25f + i * 0.17f)),
                        Offset(s * 0.85f, s * (0.25f + i * 0.17f)), strokeWidth = s * 0.07f, cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun WeatherWidget(cfg: WidgetCfg) {
    val name = cfg.props["name"] ?: "TP. Hồ Chí Minh"
    val lat = cfg.props["lat"]?.toDoubleOrNull() ?: 10.8231
    val lon = cfg.props["lon"]?.toDoubleOrNull() ?: 106.6297
    var data by remember(lat, lon) { mutableStateOf<WeatherData?>(null) }
    var failed by remember(lat, lon) { mutableStateOf(false) }

    LaunchedEffect(lat, lon) {
        while (true) {
            try {
                data = withContext(Dispatchers.IO) { fetchWeather(lat, lon) }
                failed = false
            } catch (e: Exception) {
                if (data == null) failed = true
            }
            delay(if (data == null) 30_000L else 15 * 60_000L)
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().glass(18.sdp()).padding(12.sdp())) {
        val hh = maxHeight.value / LocalScale.current
        val d = data
        if (d == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                T(if (failed) "Không tải được thời tiết" else "Đang tải thời tiết…", 14, Color.White.copy(0.8f))
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        T(name, 13, Color.White.copy(0.9f), modifier = Modifier.weight(1f))
                        WeatherIcon(d.code, 20.sdp())
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        T("${d.temp}°", 40, Color.White, FontWeight.Light)
                        Column(horizontalAlignment = Alignment.End) {
                            T(wxText(d.code), 15, Color.White, FontWeight.Medium)
                            T("Cao ${d.hi}° · Thấp ${d.lo}°", 12, Color.White.copy(0.8f))
                        }
                    }
                }
                if (hh >= 150f) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        d.hours.forEach { h ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                T(h.label, 11, Color.White.copy(0.8f))
                                WeatherIcon(h.code, 22.sdp())
                                T("${h.temp}°", 13, Color.White, FontWeight.SemiBold)
                            }
                        }
                    }
                }
                if (hh >= 215f && d.days.isNotEmpty()) {
                    val gMin = d.days.minOf { it.min }
                    val gMax = d.days.maxOf { it.max }
                    Column(verticalArrangement = Arrangement.spacedBy(3.sdp())) {
                        d.days.forEach { day ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                T(day.label, 13, Color.White, FontWeight.Medium, Modifier.width(36.sdp()))
                                WeatherIcon(day.code, 20.sdp())
                                T("${day.min}°", 13, Color.White.copy(0.75f), modifier = Modifier.width(34.sdp()), align = TextAlign.End)
                                RangeBar(day.min, day.max, gMin, gMax, Modifier.weight(1f).padding(horizontal = 6.sdp()).height(5.sdp()))
                                T("${day.max}°", 13, Color.White, FontWeight.SemiBold, Modifier.width(34.sdp()))
                            }
                        }
                    }
                }
                if (hh >= 120f) {
                    T("Độ ẩm ${d.humidity}% · Mưa ${d.rainProb}%", 11, Color.White.copy(0.85f), modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun RangeBar(min: Int, max: Int, gMin: Int, gMax: Int, modifier: Modifier) {
    Canvas(modifier) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(Color.White.copy(0.25f), Offset.Zero, Size(w, h), CornerRadius(h / 2))
        val range = (gMax - gMin).coerceAtLeast(1).toFloat()
        val x0 = w * (min - gMin) / range
        val x1 = (w * (max - gMin) / range).coerceAtLeast(x0 + h)
        drawRoundRect(
            Brush.horizontalGradient(listOf(Color(0xFF7BE495), Color(0xFFFFB347)), startX = x0, endX = x1),
            Offset(x0, 0f), Size(x1 - x0, h), CornerRadius(h / 2)
        )
    }
}

// ============================================================ LỊCH

private fun buildMonth(year: Int, month0: Int): List<Int?> {
    val c = Calendar.getInstance()
    c.clear()
    c.set(year, month0, 1)
    val first = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7        // T2 = 0 ... CN = 6
    val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (first + days + 6) / 7
    val out = ArrayList<Int?>()
    for (i in 0 until rows * 7) {
        val d = i - first + 1
        out.add(if (d in 1..days) d else null)
    }
    return out
}

@Composable
fun CalendarWidget(cfg: WidgetCfg) {
    val now by rememberNow()
    val showLunar = cfg.props["lunar"] != "0"
    val y = now.get(Calendar.YEAR)
    val m = now.get(Calendar.MONTH)
    val today = now.get(Calendar.DAY_OF_MONTH)
    val cells = remember(y, m) { buildMonth(y, m) }
    val lunar = remember(y, m, showLunar) {
        if (!showLunar) emptyList<Pair<Int, Int>?>() else cells.map { d -> if (d == null) null else lunarOf(y, m, d) }
    }
    val heads = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
    Column(Modifier.fillMaxSize().glass(18.sdp()).padding(10.sdp())) {
        T("Tháng ${m + 1}, $y", 15, Color.White, FontWeight.SemiBold, Modifier.padding(bottom = 4.sdp()))
        Row(Modifier.fillMaxWidth()) {
            heads.forEachIndexed { i, s ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    T(s, 11, if (i == 6) Color(0xFFFF8A80) else Color.White.copy(0.7f), FontWeight.Medium)
                }
            }
        }
        for (r in 0 until cells.size / 7) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (c in 0 until 7) {
                    val idx = r * 7 + c
                    val d = cells[idx]
                    val isToday = d == today
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(1.sdp())
                            .clip(RoundedCornerShape(8.sdp()))
                            .background(if (isToday) Color.White.copy(0.9f) else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        if (d != null) {
                            val main = if (isToday) Color.Black else if (c == 6) Color(0xFFFF8A80) else Color.White
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                T(d.toString(), 13, main, FontWeight.Medium)
                                val lu = lunar.getOrNull(idx)
                                if (lu != null && lu.first > 0) {
                                    val s = if (lu.second == 1) "${lu.second}/${lu.first}" else lu.second.toString()
                                    T(s, 8, if (isToday) Color.DarkGray else Color.White.copy(0.55f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================ CHỨNG KHOÁN

private val UP = Color(0xFF4CD964)
private val DOWN = Color(0xFFFF5A5F)

private fun prettySymbol(s: String): String = when (s) {
    "^GSPC" -> "S&P 500"
    "^IXIC" -> "Nasdaq"
    "^DJI" -> "Dow Jones"
    "BTC-USD" -> "Bitcoin"
    "ETH-USD" -> "Ethereum"
    "GC=F" -> "Vàng"
    "CL=F" -> "Dầu WTI"
    "USDVND=X" -> "USD/VND"
    else -> s.removePrefix("^")
}

@Composable
fun StocksWidget(cfg: WidgetCfg) {
    val raw = cfg.props["symbols"] ?: DEFAULT_SYMBOLS
    val symbols = raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    var quotes by remember(raw) { mutableStateOf<List<Quote?>>(emptyList()) }

    LaunchedEffect(raw) {
        while (true) {
            val r = withContext(Dispatchers.IO) {
                symbols.map { s -> try { fetchQuote(s) } catch (e: Exception) { null } }
            }
            quotes = r
            delay(if (r.any { it != null }) 5 * 60_000L else 30_000L)
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().glass(18.sdp()).padding(12.sdp())) {
        val sc = LocalScale.current
        val n = ((maxHeight.value - 26f * sc) / (34f * sc)).toInt().coerceIn(1, 8)
        Column {
            T("Chứng khoán", 13, Color.White.copy(0.85f), FontWeight.Medium)
            Spacer(Modifier.height(4.sdp()))
            symbols.take(n).forEachIndexed { i, s -> StockRow(s, quotes.getOrNull(i)) }
        }
    }
}

@Composable
private fun StockRow(symbol: String, q: Quote?) {
    Row(Modifier.fillMaxWidth().height(34.sdp()), verticalAlignment = Alignment.CenterVertically) {
        T(prettySymbol(symbol), 14, Color.White, FontWeight.Medium, Modifier.width(86.sdp()))
        if (q == null) {
            T("—", 14, Color.White.copy(0.6f))
        } else {
            val chg = q.price - q.prev
            val col = if (chg >= 0) UP else DOWN
            val pct = if (q.prev != 0.0) chg / q.prev * 100.0 else 0.0
            Canvas(Modifier.weight(1f).height(18.sdp()).padding(horizontal = 6.sdp())) {
                val pts = q.spark
                if (pts.size > 1) {
                    val mn = pts.min()
                    val mx = pts.max()
                    val rng = (mx - mn).coerceAtLeast(1e-6f)
                    val p = Path()
                    pts.forEachIndexed { i, v ->
                        val x = this.size.width * i / (pts.size - 1)
                        val y = this.size.height * (1f - (v - mn) / rng)
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    drawPath(p, col, style = Stroke(width = 2f, cap = StrokeCap.Round))
                }
            }
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(92.sdp())) {
                val priceStr = if (q.price >= 1000) String.format(Locale.US, "%,.0f", q.price) else String.format(Locale.US, "%.2f", q.price)
                T(priceStr, 13, Color.White, FontWeight.SemiBold)
                T(String.format(Locale.US, "%+.2f%%", pct), 11, col)
            }
        }
    }
}
