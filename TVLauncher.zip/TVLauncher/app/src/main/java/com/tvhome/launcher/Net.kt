package com.tvhome.launcher

import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs

object Net {
    private const val UA = "Mozilla/5.0 (Linux; Android 11; TV) AppleWebKit/537.36 (KHTML, like Gecko) TVLauncher/1.0"

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun download(url: String, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            c.inputStream.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        } finally {
            c.disconnect()
        }
    }
}

// ---------------------------------------------------------------- Thời tiết (Open-Meteo, không cần API key)

data class HourPt(val label: String, val temp: Int, val code: Int)
data class DayPt(val label: String, val min: Int, val max: Int, val code: Int)
data class WeatherData(
    val temp: Int, val code: Int, val hi: Int, val lo: Int,
    val humidity: Int, val rainProb: Int,
    val hours: List<HourPt>, val days: List<DayPt>
)

data class GeoPlace(val name: String, val lat: Double, val lon: Double, val country: String)

fun fetchWeather(lat: Double, lon: Double): WeatherData {
    val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,weather_code" +
            "&hourly=temperature_2m,weather_code" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=5"
    val root = JSONObject(Net.get(url))
    val cur = root.getJSONObject("current")
    val curTime = cur.getString("time")                       // 2026-10-26T08:45
    val hourKey = curTime.substring(0, 13) + ":00"

    val hourly = root.getJSONObject("hourly")
    val ht = hourly.getJSONArray("time")
    val htemp = hourly.getJSONArray("temperature_2m")
    val hcode = hourly.getJSONArray("weather_code")
    var idx = 0
    for (i in 0 until ht.length()) if (ht.getString(i) == hourKey) {
        idx = i; break
    }
    val hours = ArrayList<HourPt>()
    for (i in idx until minOf(idx + 5, ht.length())) {
        hours.add(HourPt(ht.getString(i).substring(11, 16), Math.round(htemp.optDouble(i, 0.0)).toInt(), hcode.optInt(i, 0)))
    }

    val daily = root.getJSONObject("daily")
    val dt = daily.getJSONArray("time")
    val dcode = daily.getJSONArray("weather_code")
    val dmax = daily.getJSONArray("temperature_2m_max")
    val dmin = daily.getJSONArray("temperature_2m_min")
    val dprob = daily.getJSONArray("precipitation_probability_max")
    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val days = ArrayList<DayPt>()
    for (i in 1 until minOf(4, dt.length())) {
        val cal = Calendar.getInstance()
        cal.time = fmt.parse(dt.getString(i))!!
        val dow = cal.get(Calendar.DAY_OF_WEEK)               // CN=1, T2=2 ...
        val label = if (dow == Calendar.SUNDAY) "CN" else "Th $dow"
        days.add(
            DayPt(
                label,
                Math.round(dmin.optDouble(i, 0.0)).toInt(),
                Math.round(dmax.optDouble(i, 0.0)).toInt(),
                dcode.optInt(i, 0)
            )
        )
    }
    return WeatherData(
        temp = Math.round(cur.optDouble("temperature_2m", 0.0)).toInt(),
        code = cur.optInt("weather_code", 0),
        hi = Math.round(dmax.optDouble(0, 0.0)).toInt(),
        lo = Math.round(dmin.optDouble(0, 0.0)).toInt(),
        humidity = cur.optInt("relative_humidity_2m", 0),
        rainProb = dprob.optInt(0, 0),
        hours = hours,
        days = days
    )
}

fun geocode(q: String): List<GeoPlace> {
    val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(q, "UTF-8") + "&count=6&language=vi&format=json"
    val arr = JSONObject(Net.get(url)).optJSONArray("results") ?: return emptyList()
    val out = ArrayList<GeoPlace>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(GeoPlace(o.optString("name"), o.getDouble("latitude"), o.getDouble("longitude"), o.optString("country")))
    }
    return out
}

/** 0 nắng, 1 ít mây, 2 nhiều mây, 3 mưa, 4 giông, 5 tuyết, 6 sương mù */
fun wxKind(code: Int): Int = when (code) {
    0 -> 0
    1, 2 -> 1
    3 -> 2
    45, 48 -> 6
    51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> 3
    71, 73, 75, 77, 85, 86 -> 5
    95, 96, 99 -> 4
    else -> 2
}

fun wxText(code: Int): String = when (code) {
    0 -> "Trời quang"
    1 -> "Ít mây"
    2 -> "Có mây"
    3 -> "Nhiều mây"
    45, 48 -> "Sương mù"
    51, 53, 55, 56, 57 -> "Mưa phùn"
    61, 63, 65 -> "Có mưa"
    66, 67 -> "Mưa lạnh"
    71, 73, 75, 77, 85, 86 -> "Có tuyết"
    80, 81, 82 -> "Mưa rào"
    95, 96, 99 -> "Giông bão"
    else -> "—"
}

// ---------------------------------------------------------------- Chứng khoán (Yahoo Finance, không chính thức)

data class Quote(val symbol: String, val price: Double, val prev: Double, val spark: List<Float>)

fun fetchQuote(symbol: String): Quote? {
    val url = "https://query1.finance.yahoo.com/v8/finance/chart/" +
            URLEncoder.encode(symbol, "UTF-8") + "?range=1mo&interval=1d"
    val res = JSONObject(Net.get(url)).getJSONObject("chart").optJSONArray("result") ?: return null
    if (res.length() == 0) return null
    val r = res.getJSONObject(0)
    val meta = r.getJSONObject("meta")
    val price = meta.optDouble("regularMarketPrice", Double.NaN)
    if (price.isNaN()) return null
    val closeArr = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close")
    val closes = ArrayList<Double>()
    for (i in 0 until closeArr.length()) {
        val v = closeArr.optDouble(i, Double.NaN)
        if (!v.isNaN()) closes.add(v)
    }
    val prev: Double = if (closes.isNotEmpty() && abs(closes.last() - price) > 1e-6 * maxOf(price, 1.0)) {
        closes.last()
    } else {
        closes.getOrNull(closes.size - 2) ?: meta.optDouble("chartPreviousClose", price)
    }
    return Quote(symbol, price, prev, closes.map { it.toFloat() })
}
