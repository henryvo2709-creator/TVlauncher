package com.tvhome.launcher

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Environment
import android.os.StatFs
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ============================================================ WIDGET HOST + CHẾ ĐỘ CHỈNH SỬA

@Composable
fun WidgetsHost(
    store: LauncherStore,
    editing: Boolean,
    selectedId: String?,
    grabbedId: String?,
    onSelect: (String) -> Unit,
    onGrab: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val cellW = maxWidth / COLS
        val cellH = maxHeight / ROWS
        store.widgets.forEach { cfg ->
            key(cfg.id) {
                Box(
                    Modifier
                        .offset(cellW * cfg.x, cellH * cfg.y)
                        .size(cellW * cfg.w, cellH * cfg.h)
                        .padding(5.sdp())
                ) {
                    WidgetContent(cfg, editing)
                    if (editing) {
                        EditOverlay(
                            selected = selectedId == cfg.id,
                            grabbed = grabbedId == cfg.id,
                            onSelect = { onSelect(cfg.id) },
                            onGrabToggle = { onGrab(if (grabbedId == cfg.id) null else cfg.id) },
                            onMove = { dx, dy -> store.move(cfg.id, dx, dy) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditOverlay(
    selected: Boolean,
    grabbed: Boolean,
    onSelect: () -> Unit,
    onGrabToggle: () -> Unit,
    onMove: (Int, Int) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val borderColor = when {
        grabbed -> Color(0xFFFFD54F)
        focused || selected -> Color.White
        else -> Color.White.copy(alpha = 0.35f)
    }
    val borderW = if (grabbed) 4.dp else if (focused) 3.dp else 1.5.dp
    Box(
        Modifier
            .fillMaxSize()
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onSelect()
            }
            .onKeyEvent { e ->
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter
                if (grabbed && e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.DirectionLeft -> { onMove(-1, 0); true }
                        Key.DirectionRight -> { onMove(1, 0); true }
                        Key.DirectionUp -> { onMove(0, -1); true }
                        Key.DirectionDown -> { onMove(0, 1); true }
                        else -> ok
                    }
                } else if (ok && e.type == KeyEventType.KeyUp) {
                    onGrabToggle()
                    true
                } else {
                    false
                }
            }
            .focusable()
            .border(borderW, borderColor, RoundedCornerShape(18.sdp()))
            .background(
                if (grabbed) Color(0x33FFD54F) else Color(0x14FFFFFF),
                RoundedCornerShape(18.sdp())
            )
    )
}

@Composable
fun EditToolbar(
    first: FocusRequester,
    onAdd: () -> Unit,
    onW: (Int) -> Unit,
    onH: (Int) -> Unit,
    onSettings: () -> Unit,
    onDelete: () -> Unit,
    onWallpaper: () -> Unit,
    onDone: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.sdp()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PillButton("+ Widget", focusRequester = first, onClick = onAdd)
        PillButton("Rộng +") { onW(1) }
        PillButton("Rộng -") { onW(-1) }
        PillButton("Cao +") { onH(1) }
        PillButton("Cao -") { onH(-1) }
        PillButton("Cài đặt", onClick = onSettings)
        PillButton("Xóa", onClick = onDelete)
        PillButton("Hình nền", onClick = onWallpaper)
        PillButton("Xong", active = true, onClick = onDone)
    }
}

// ============================================================ THANH TRÊN

@Composable
fun TopBar(label: String, onForceQuit: () -> Unit, onRestart: () -> Unit) {
    val ctx = LocalContext.current
    var ram by remember { mutableFloatStateOf(0f) }
    var rom by remember { mutableFloatStateOf(0f) }
    var net by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            val r = withContext(Dispatchers.IO) {
                var a = 0f
                var b = 0f
                var n = 0
                try {
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val mi = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(mi)
                    if (mi.totalMem > 0) a = 1f - mi.availMem.toFloat() / mi.totalMem.toFloat()
                    val sf = StatFs(Environment.getDataDirectory().path)
                    if (sf.totalBytes > 0) b = 1f - sf.availableBytes.toFloat() / sf.totalBytes.toFloat()
                    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                    n = when {
                        caps == null -> 0
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 2
                        else -> 3
                    }
                } catch (e: Exception) {
                }
                Triple(a, b, n)
            }
            ram = r.first
            rom = r.second
            net = r.third
            delay(5000)
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.sdp())) {
            T(label, 22, Color.White, FontWeight.SemiBold, Modifier.width(150.sdp()))
            PillButton("Force Quit", onClick = onForceQuit)
            PillButton("Restart", onClick = onRestart)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.sdp())) {
            Meter("Ram", ram)
            Meter("Rom", rom)
            NetIcon(net)
        }
    }
}

@Composable
private fun Meter(name: String, frac: Float) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.sdp())) {
        T(name, 16, Color.White, FontWeight.Medium)
        Canvas(Modifier.size(18.sdp())) {
            val s = this.size.minDimension
            val sw = s * 0.16f
            drawCircle(Color.White.copy(0.9f), s / 2 - sw / 2, style = Stroke(width = sw))
            drawArc(
                Color.White, -90f, 360f * frac.coerceIn(0f, 1f), true,
                Offset(sw * 1.4f, sw * 1.4f), Size(s - sw * 2.8f, s - sw * 2.8f)
            )
        }
    }
}

@Composable
private fun NetIcon(kind: Int) {
    if (kind == 2) {
        T("ETH", 14, Color.White, FontWeight.Bold)
        return
    }
    Canvas(Modifier.size(22.sdp())) {
        val s = this.size.minDimension
        val col = Color.White.copy(if (kind == 0) 0.3f else 1f)
        val c = Offset(s / 2, s * 0.85f)
        for (i in 1..3) {
            val r = s * 0.28f * i
            drawArc(
                col, -135f, 90f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2),
                style = Stroke(width = s * 0.1f, cap = StrokeCap.Round)
            )
        }
        drawCircle(col, s * 0.07f, c)
    }
}

// ============================================================ DOCK

@Composable
private fun DockItem(
    modifier: Modifier = Modifier,
    onFocus: (Boolean) -> Unit = {},
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.22f else 1f, label = "dockScale")
    Box(
        modifier
            .size(64.sdp())
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .onFocusChanged {
                focused = it.isFocused
                onFocus(it.isFocused)
            }
            .clip(RoundedCornerShape(16.sdp()))
            .background(if (focused) Color.White.copy(alpha = 0.35f) else Color.Transparent)
            .tvClickable(onLong, onClick)
            .padding(5.sdp()),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun Dock(
    items: List<AppEntry>,
    firstFocus: FocusRequester,
    onFocusApp: (AppEntry) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    onAllApps: () -> Unit,
    onEdit: () -> Unit,
    onSettings: () -> Unit
) {
    val shape = RoundedCornerShape(26.sdp())
    Row(
        Modifier
            .background(Color(0x66101018), shape)
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .padding(horizontal = 12.sdp(), vertical = 10.sdp()),
        horizontalArrangement = Arrangement.spacedBy(10.sdp()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { i, app ->
            key(app.pkg) {
                DockItem(
                    modifier = if (i == 0) Modifier.focusRequester(firstFocus) else Modifier,
                    onFocus = { if (it) onFocusApp(app) },
                    onLong = { onMenu(app) },
                    onClick = { onLaunch(app) }
                ) {
                    Image(app.icon, app.label, Modifier.fillMaxSize())
                }
            }
        }
        if (items.isNotEmpty()) {
            Box(Modifier.width(1.dp).height(36.sdp()).background(Color.White.copy(0.25f)))
        }
        DockItem(
            modifier = if (items.isEmpty()) Modifier.focusRequester(firstFocus) else Modifier,
            onClick = onAllApps
        ) { GlyphTile { AppsGlyph() } }
        DockItem(onClick = onEdit) { GlyphTile { EditGlyph() } }
        DockItem(onClick = onSettings) { GlyphTile { GearGlyph() } }
    }
}

@Composable
private fun GlyphTile(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(14.sdp())).background(Color(0xFF3B3F52)).padding(10.sdp()),
        content = content
    )
}

@Composable
private fun AppsGlyph() {
    val cols = listOf(
        Color(0xFFFF5F6D), Color(0xFFFFC371), Color(0xFF5BE584),
        Color(0xFF4FC3F7), Color(0xFFB36BFF), Color(0xFFFF8AD8),
        Color(0xFF7BE495), Color(0xFFFFB347), Color(0xFF6EC1FF)
    )
    Canvas(Modifier.fillMaxSize()) {
        val s = this.size.minDimension
        val cell = s / 3f
        for (i in 0 until 9) {
            val r = i / 3
            val c = i % 3
            drawRoundRect(
                cols[i], Offset(c * cell + cell * 0.1f, r * cell + cell * 0.1f),
                Size(cell * 0.8f, cell * 0.8f), CornerRadius(cell * 0.2f)
            )
        }
    }
}

@Composable
private fun EditGlyph() {
    Canvas(Modifier.fillMaxSize()) {
        val w = this.size.width
        val h = this.size.height
        val knobs = listOf(0.3f, 0.7f, 0.45f)
        for (i in 0 until 3) {
            val y = h * (0.2f + i * 0.3f)
            drawLine(Color.White.copy(0.7f), Offset(0f, y), Offset(w, y), strokeWidth = h * 0.07f, cap = StrokeCap.Round)
            drawCircle(Color.White, h * 0.1f, Offset(w * knobs[i], y))
        }
    }
}

@Composable
private fun GearGlyph() {
    Canvas(Modifier.fillMaxSize()) {
        val s = this.size.minDimension
        val c = Offset(this.size.width / 2, this.size.height / 2)
        for (i in 0 until 8) {
            rotate(i * 45f, c) {
                drawRoundRect(
                    Color.White, Offset(c.x - s * 0.07f, c.y - s * 0.5f),
                    Size(s * 0.14f, s * 0.24f), CornerRadius(3f)
                )
            }
        }
        drawCircle(Color.White, s * 0.34f, c)
        drawCircle(Color(0xFF3B3F52), s * 0.16f, c)
    }
}
