package com.tvhome.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Calendar

/** Hệ số co giãn UI theo độ rộng màn hình (960dp = 1.0). */
val LocalScale = compositionLocalOf { 1f }

@Composable
@ReadOnlyComposable
fun Number.ssp(): TextUnit = (this.toFloat() * LocalScale.current).sp

@Composable
@ReadOnlyComposable
fun Number.sdp(): Dp = (this.toFloat() * LocalScale.current).dp

/** Nền kính tối mờ cho widget. */
fun Modifier.glass(radius: Dp): Modifier = this
    .background(Color(0x55101018), RoundedCornerShape(radius))
    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(radius))

@Composable
fun T(
    text: String,
    size: Number = 14,
    color: Color = Color.White,
    weight: FontWeight? = null,
    modifier: Modifier = Modifier,
    maxLines: Int = 1,
    align: TextAlign? = null
) {
    Text(
        text,
        modifier = modifier,
        color = color,
        fontSize = size.ssp(),
        fontWeight = weight,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align
    )
}

/**
 * Click bằng remote (OK / Enter), chuột/cảm ứng, kèm nhấn giữ OK hoặc phím Menu = onLong.
 * Đã bao gồm focusable().
 */
@Composable
fun Modifier.tvClickable(onLong: (() -> Unit)? = null, onClick: () -> Unit): Modifier {
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLong)
    var longFired by remember { mutableStateOf(false) }
    return this
        .pointerInput(Unit) {
            detectTapGestures(
                onTap = { click() },
                onLongPress = { long?.invoke() }
            )
        }
        .onKeyEvent { e ->
            val k = e.key
            val isOk = k == Key.DirectionCenter || k == Key.Enter || k == Key.NumPadEnter
            if (isOk) {
                when (e.type) {
                    KeyEventType.KeyDown -> {
                        val ne = e.nativeKeyEvent
                        if (ne.repeatCount == 0) longFired = false
                        if (ne.repeatCount > 0 && !longFired && long != null) {
                            longFired = true
                            long?.invoke()
                        }
                        true
                    }
                    KeyEventType.KeyUp -> {
                        if (!longFired) click()
                        longFired = false
                        true
                    }
                    else -> false
                }
            } else if (k == Key.Menu && e.type == KeyEventType.KeyUp && long != null) {
                long?.invoke()
                true
            } else {
                false
            }
        }
        .focusable()
}

@Composable
fun PillButton(
    text: String,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    active: Boolean = false,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val bg = when {
        focused -> Color.White.copy(alpha = 0.92f)
        active -> Color.White.copy(alpha = 0.38f)
        else -> Color.White.copy(alpha = 0.16f)
    }
    Box(
        modifier
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(50))
            .background(bg)
            .tvClickable(onLong, onClick)
            .padding(horizontal = 14.sdp(), vertical = 7.sdp()),
        contentAlignment = Alignment.Center
    ) {
        T(text, 14, if (focused) Color.Black else Color.White, FontWeight.Medium)
    }
}

@Composable
fun rememberNow(): State<Calendar> {
    val st = remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            val ms = System.currentTimeMillis()
            delay(60_000L - ms % 60_000L + 30L)
            st.value = Calendar.getInstance()
        }
    }
    return st
}

@Composable
fun AutoFocus(fr: FocusRequester) {
    LaunchedEffect(Unit) {
        delay(120)
        try {
            fr.requestFocus()
        } catch (e: Exception) {
        }
    }
}
